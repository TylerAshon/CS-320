import org.junit.jupiter.api.Test;
import static org.junit.jupiter.api.Assertions.*;

/**
 * Unit tests for the TaskService class.
 */
public class TaskServiceTest {

    @Test
    public void testAddTask() {
        // Test adding a task
        TaskService service = new TaskService();
        Task task = new Task("123", "Task", "Description");
        service.addTask(task);
        assertEquals(task, service.getTask("123"));
    }

    @Test
    public void testAddDuplicateTask() {
        // Test adding a task with a duplicate ID
        TaskService service = new TaskService();
        Task task = new Task("123", "Task", "Description");
        service.addTask(task);
        assertThrows(IllegalArgumentException.class, () -> service.addTask(new Task("123", "Another Task", "Another Description")));
    }

    @Test
    public void testDeleteTask() {
        // Test deleting a task
        TaskService service = new TaskService();
        Task task = new Task("123", "Task", "Description");
        service.addTask(task);
        service.deleteTask("123");
        assertNull(service.getTask("123"));
    }

    @Test
    public void testDeleteNonexistentTask() {
        // Test deleting a task that does not exist
        TaskService service = new TaskService();
        assertThrows(IllegalArgumentException.class, () -> service.deleteTask("123"));
    }

    @Test
    public void testUpdateTaskName() {
        // Test updating a task's name
        TaskService service = new TaskService();
        Task task = new Task("123", "Task", "Description");
        service.addTask(task);
        service.updateTaskName("123", "Updated Name");
        assertEquals("Updated Name", service.getTask("123").getName());
    }

    @Test
    public void testUpdateTaskDescription() {
        // Test updating a task's description
        TaskService service = new TaskService();
        Task task = new Task("123", "Task", "Description");
        service.addTask(task);
        service.updateTaskDescription("123", "Updated Description");
        assertEquals("Updated Description", service.getTask("123").getDescription());
    }

    @Test
    public void testUpdateNonexistentTask() {
        // Test updating a non-existent task
        TaskService service = new TaskService();
        assertThrows(IllegalArgumentException.class, () -> service.updateTaskName("123", "Name"));
        assertThrows(IllegalArgumentException.class, () -> service.updateTaskDescription("123", "Description"));
    }
}
