import org.junit.jupiter.api.Test;
import static org.junit.jupiter.api.Assertions.*;

import java.util.Date;

public class AppointmentServiceTest {

    @Test
    public void testAddAppointment() {
        AppointmentService service = new AppointmentService();
        Appointment appointment = new Appointment("12345", new Date(System.currentTimeMillis() + 10000), "Doctor visit");

        service.addAppointment(appointment);
        assertEquals(appointment, service.getAppointment("12345"));
    }

    @Test
    public void testAddDuplicateAppointment() {
        AppointmentService service = new AppointmentService();
        Appointment appointment = new Appointment("12345", new Date(System.currentTimeMillis() + 10000), "Doctor visit");

        service.addAppointment(appointment);

        assertThrows(IllegalArgumentException.class, () -> {
            service.addAppointment(appointment);
        });
    }

    @Test
    public void testDeleteAppointment() {
        AppointmentService service = new AppointmentService();
        Appointment appointment = new Appointment("12345", new Date(System.currentTimeMillis() + 10000), "Doctor visit");

        service.addAppointment(appointment);
        service.deleteAppointment("12345");

        assertNull(service.getAppointment("12345"));
    }

    @Test
    public void testDeleteNonExistentAppointment() {
        AppointmentService service = new AppointmentService();
        assertThrows(IllegalArgumentException.class, () -> {
            service.deleteAppointment("nonexistent");
        });
    }
}
