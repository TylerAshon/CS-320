/**
 * The Task class represents a task object with fields for a unique ID, name, and description.
 * It enforces constraints on these fields such as length and non-null requirements.
 */
public class Task {
    // Final field to ensure the task ID is immutable
    private final String taskId;
    private String name;
    private String description;

    /**
     * Constructor for creating a Task object.
     *
     * @param taskId      The unique ID for the task (required, max 10 characters, non-null)
     * @param name        The name of the task (required, max 20 characters, non-null)
     * @param description The description of the task (required, max 50 characters, non-null)
     */
    public Task(String taskId, String name, String description) {
        // Validate the task ID
        if (taskId == null || taskId.length() > 10) {
            throw new IllegalArgumentException("Task ID must not be null and cannot exceed 10 characters.");
        }

        // Validate the name field
        if (name == null || name.length() > 20) {
            throw new IllegalArgumentException("Task name must not be null and cannot exceed 20 characters.");
        }

        // Validate the description field
        if (description == null || description.length() > 50) {
            throw new IllegalArgumentException("Task description must not be null and cannot exceed 50 characters.");
        }

        this.taskId = taskId;
        this.name = name;
        this.description = description;
    }

    /**
     * Gets the task ID.
     *
     * @return The task ID
     */
    public String getTaskId() {
        return taskId;
    }

    /**
     * Gets the name of the task.
     *
     * @return The task name
     */
    public String getName() {
        return name;
    }

    /**
     * Updates the name of the task.
     *
     * @param name The new name for the task (must not be null or exceed 20 characters)
     */
    public void setName(String name) {
        if (name == null || name.length() > 20) {
            throw new IllegalArgumentException("Task name must not be null and cannot exceed 20 characters.");
        }
        this.name = name;
    }

    /**
     * Gets the description of the task.
     *
     * @return The task description
     */
    public String getDescription() {
        return description;
    }

    /**
     * Updates the description of the task.
     *
     * @param description The new description for the task (must not be null or exceed 50 characters)
     */
    public void setDescription(String description) {
        if (description == null || description.length() > 50) {
            throw new IllegalArgumentException("Task description must not be null and cannot exceed 50 characters.");
        }
        this.description = description;
    }
}
