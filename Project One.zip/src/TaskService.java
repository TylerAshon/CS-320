import java.util.HashMap;
import java.util.Map;

/**
 * The TaskService class manages task objects, allowing the addition, deletion,
 * and updating of tasks. Tasks are stored in an in-memory data structure.
 */
public class TaskService {
    // Map to store tasks, with the task ID as the key
    private final Map<String, Task> tasks;

    /**
     * Constructor for initializing the task service with an empty task map.
     */
    public TaskService() {
        this.tasks = new HashMap<>();
    }

    /**
     * Adds a task to the service.
     *
     * @param task The task to be added (task ID must be unique)
     * @throws IllegalArgumentException if a task with the same ID already exists
     */
    public void addTask(Task task) {
        if (tasks.containsKey(task.getTaskId())) {
            throw new IllegalArgumentException("Task with this ID already exists.");
        }
        tasks.put(task.getTaskId(), task);
    }

    /**
     * Deletes a task from the service.
     *
     * @param taskId The ID of the task to be deleted
     * @throws IllegalArgumentException if no task with the given ID exists
     */
    public void deleteTask(String taskId) {
        if (!tasks.containsKey(taskId)) {
            throw new IllegalArgumentException("Task with this ID does not exist.");
        }
        tasks.remove(taskId);
    }

    /**
     * Updates the name of a task.
     *
     * @param taskId The ID of the task to be updated
     * @param name   The new name for the task
     * @throws IllegalArgumentException if the task ID does not exist
     */
    public void updateTaskName(String taskId, String name) {
        Task task = tasks.get(taskId);
        if (task == null) {
            throw new IllegalArgumentException("Task with this ID does not exist.");
        }
        task.setName(name);
    }

    /**
     * Updates the description of a task.
     *
     * @param taskId      The ID of the task to be updated
     * @param description The new description for the task
     * @throws IllegalArgumentException if the task ID does not exist
     */
    public void updateTaskDescription(String taskId, String description) {
        Task task = tasks.get(taskId);
        if (task == null) {
            throw new IllegalArgumentException("Task with this ID does not exist.");
        }
        task.setDescription(description);
    }

    /**
     * Retrieves a task by its ID.
     *
     * @param taskId The ID of the task to retrieve
     * @return The task object, or null if not found
     */
    public Task getTask(String taskId) {
        return tasks.get(taskId);
    }
}
