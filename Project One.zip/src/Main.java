import java.util.Date;

public class Main {
    public static void main(String[] args) {
        // Initialize services
        ContactService contactService = new ContactService();
        TaskService taskService = new TaskService();
        AppointmentService appointmentService = new AppointmentService();

        // ********** CONTACT SERVICE DEMO **********
        System.out.println("---- CONTACT SERVICE ----");
        Contact contact1 = new Contact("C001", "John", "Doe", "1234567890", "123 Main St");
        Contact contact2 = new Contact("C002", "Jane", "Smith", "0987654321", "456 Elm St");

        // Add contacts
        contactService.addContact(contact1);
        contactService.addContact(contact2);
        System.out.println("Added contacts: " + contactService.getContact("C001").getFirstName() + ", " + contactService.getContact("C002").getFirstName());

        // Update a contact
        contactService.updateContact("C001", "Johnny", null, null, null);
        System.out.println("Updated C001 First Name: " + contactService.getContact("C001").getFirstName());

        // Delete a contact
        contactService.deleteContact("C002");
        System.out.println("C002 exists after deletion: " + (contactService.getContact("C002") != null));

        // ********** TASK SERVICE DEMO **********
        System.out.println("\n---- TASK SERVICE ----");
        Task task1 = new Task("T001", "Code Review", "Review PR #123");
        Task task2 = new Task("T002", "Testing", "Unit test for login module");

        // Add tasks
        taskService.addTask(task1);
        taskService.addTask(task2);
        System.out.println("Added tasks: " + taskService.getTask("T001").getName() + ", " + taskService.getTask("T002").getName());

        // Update a task
        taskService.updateTaskName("T001", "Code Refactoring");
        System.out.println("Updated Task Name T001: " + taskService.getTask("T001").getName());

        // Delete a task
        taskService.deleteTask("T002");
        System.out.println("T002 exists after deletion: " + (taskService.getTask("T002") != null));

        // ********** APPOINTMENT SERVICE DEMO **********
        System.out.println("\n---- APPOINTMENT SERVICE ----");
        Appointment appointment1 = new Appointment("A001", new Date(System.currentTimeMillis() + 1000000), "Doctor Visit");
        Appointment appointment2 = new Appointment("A002", new Date(System.currentTimeMillis() + 2000000), "Team Meeting");

        // Add appointments
        appointmentService.addAppointment(appointment1);
        appointmentService.addAppointment(appointment2);
        System.out.println("Added appointments: " + appointmentService.getAppointment("A001").getDescription() + ", " + appointmentService.getAppointment("A002").getDescription());

        // Delete an appointment
        appointmentService.deleteAppointment("A002");
        System.out.println("A002 exists after deletion: " + (appointmentService.getAppointment("A002") != null));

        // END OF DEMO
        System.out.println("\nAll services executed successfully.");
    }
}
