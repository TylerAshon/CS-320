import org.junit.jupiter.api.Test;
import java.util.Date;

import static org.junit.jupiter.api.Assertions.*;

public class AppointmentTest {

    @Test
    public void testValidAppointment() {
        Appointment appointment = new Appointment("12345", new Date(System.currentTimeMillis() + 10000), "Doctor visit");
        assertNotNull(appointment);
        assertEquals("12345", appointment.getAppointmentId());
        assertEquals("Doctor visit", appointment.getDescription());
    }

    @Test
    public void testInvalidAppointmentId() {
        assertThrows(IllegalArgumentException.class, () -> {
            new Appointment(null, new Date(), "Meeting");
        });

        assertThrows(IllegalArgumentException.class, () -> {
            new Appointment("12345678901", new Date(), "Meeting");
        });
    }

    @Test
    public void testInvalidAppointmentDate() {
        assertThrows(IllegalArgumentException.class, () -> {
            new Appointment("12345", new Date(System.currentTimeMillis() - 10000), "Meeting");
        });
    }

    @Test
    public void testInvalidDescription() {
        assertThrows(IllegalArgumentException.class, () -> {
            new Appointment("12345", new Date(), null);
        });

        assertThrows(IllegalArgumentException.class, () -> {
            new Appointment("12345", new Date(), "This description is more than fifty characters long, which is invalid.");
        });
    }
}
