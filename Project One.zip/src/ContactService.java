import java.util.HashMap;
import java.util.Map;

// This class manages a collection of Contact objects and provides operations on them.
public class ContactService {
    private final Map<String, Contact> contacts = new HashMap<>(); // Stores contacts with contactId as the key

    // Adds a new contact to the service
    public void addContact(Contact contact) {
        // Ensure contactId is unique
        if (contacts.containsKey(contact.getContactId())) {
            throw new IllegalArgumentException("Contact ID already exists");
        }
        // Add the contact to the map
        contacts.put(contact.getContactId(), contact);
    }

    // Deletes a contact from the service using the contactId
    public void deleteContact(String contactId) {
        // Check if the contact exists
        if (!contacts.containsKey(contactId)) {
            throw new IllegalArgumentException("Contact ID not found");
        }
        // Remove the contact from the map
        contacts.remove(contactId);
    }

    // Updates an existing contact's fields using the contactId
    public void updateContact(String contactId, String firstName, String lastName, String phone, String address) {
        // Ensure the contact exists
        if (!contacts.containsKey(contactId)) {
            throw new IllegalArgumentException("Contact ID not found");
        }

        // Retrieve the contact and update fields as provided
        Contact contact = contacts.get(contactId);
        if (firstName != null) contact.setFirstName(firstName);
        if (lastName != null) contact.setLastName(lastName);
        if (phone != null) contact.setPhone(phone);
        if (address != null) contact.setAddress(address);
    }

    // Retrieves a contact by contactId
    public Contact getContact(String contactId) {
        return contacts.get(contactId); // Returns null if the contact doesn't exist
    }
}
