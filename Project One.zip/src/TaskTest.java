import org.junit.jupiter.api.Test;
import static org.junit.jupiter.api.Assertions.*;

/**
 * Unit tests for the Task class.
 */
public class TaskTest {

    @Test
    public void testTaskCreationValid() {
        // Test valid task creation
        Task task = new Task("12345", "Test Task", "This is a test task.");
        assertEquals("12345", task.getTaskId());
        assertEquals("Test Task", task.getName());
        assertEquals("This is a test task.", task.getDescription());
    }

    @Test
    public void testTaskCreationInvalidId() {
        // Test task creation with invalid task ID
        assertThrows(IllegalArgumentException.class, () -> new Task(null, "Task", "Description"));
        assertThrows(IllegalArgumentException.class, () -> new Task("12345678901", "Task", "Description"));
    }

    @Test
    public void testTaskCreationInvalidName() {
        // Test task creation with invalid name
        assertThrows(IllegalArgumentException.class, () -> new Task("123", null, "Description"));
        assertThrows(IllegalArgumentException.class, () -> new Task("123", "This name is too long for the field", "Description"));
    }

    @Test
    public void testTaskCreationInvalidDescription() {
        // Test task creation with invalid description
        assertThrows(IllegalArgumentException.class, () -> new Task("123", "Task", null));
        assertThrows(IllegalArgumentException.class, () -> new Task("123", "Task", "This description is far too long and exceeds the maximum limit of fifty characters."));
    }

    @Test
    public void testSetNameValid() {
        // Test setting a valid task name
        Task task = new Task("123", "Task", "Description");
        task.setName("Updated Name");
        assertEquals("Updated Name", task.getName());
    }

    @Test
    public void testSetDescriptionValid() {
        // Test setting a valid task description
        Task task = new Task("123", "Task", "Description");
        task.setDescription("Updated Description");
        assertEquals("Updated Description", task.getDescription());
    }
}
